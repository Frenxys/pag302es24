package solamenteTuuu;

public class Main {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Terminale t=new Terminale();
		t.creaOperazione(new Operazione(3,3,"ciao",'e'));
		t.creaOperazione(new Operazione(2,1,"ciao2",'u'));
		/*
	 	t.visualizzaOperazione("ciao");
		t.eliminaOperazione();
		t.visualizzaOperazioni();
		*/
		stampaArrayString(t.getOperazioni());
	}
	
	public static void stampaArrayString(String[] array) {
		for(String a:array) {
			System.out.println(a);
			System.out.println("\n");
		}
	}
	
}
